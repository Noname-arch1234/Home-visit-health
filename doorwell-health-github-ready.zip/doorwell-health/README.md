# Doorwell Health website

A responsive, static website for Doorwell Health's doctor home-visit appointment requests across Chennai.

## Included
- Responsive homepage and service information
- Patient appointment request form that opens WhatsApp
- Click-to-call and WhatsApp contact links
- User-supplied logo in `assets/doorwell-logo.jpg`
- No admin dashboard, payment collection, patient database, or server-side storage

## Before publishing
1. Confirm that **+91 87789 66138** is the correct public contact number and is registered on WhatsApp.
2. Review the service descriptions, consultation price wording, service coverage and emergency disclaimer.
3. If you want to change the contact number, update `PHONE` in `script.js` and the `tel:` / `wa.me` links in `index.html`.
4. The appointment form sends the details entered by the patient to WhatsApp. Do not ask patients to submit medical records, identity documents, or highly sensitive health information through this form.
5. Confirm applicable professional, business, privacy and healthcare requirements before accepting bookings.

## Publish with GitHub Pages
1. Create a new **public** GitHub repository, for example `doorwell-health`.
2. Upload all files and folders from this project. Keep `index.html` in the repository root.
3. In the repository, open **Settings → Pages**.
4. Under **Build and deployment**, select **Deploy from a branch**.
5. Select branch `main` and folder `/ (root)`, then save.
6. Wait for GitHub Pages to publish the site. GitHub will show the published address in Settings → Pages.

## Connect a Namecheap domain later
In GitHub Pages settings, add your custom domain first and follow GitHub's current DNS instructions. Then add the exact DNS records in Namecheap Advanced DNS. Enable HTTPS after DNS verification. Do not share your Namecheap password or GitHub recovery codes.

## Important limitations
This is a static first version. It does not store bookings or assign doctors automatically. Each patient submits a request through WhatsApp; your team must review availability and confirm the appointment manually. A future secure backend/admin dashboard should be built separately if you need online booking management.
